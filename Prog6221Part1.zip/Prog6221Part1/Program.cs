﻿public class Recipe
{
    public string Name { get; set; }
    public List<string> Ingredients { get; set; }
    public List<string> Units { get; set; }
    public List<string> Instructions { get; set; }
}

class Program
{
    static void Main(string[] args)
    {
        var recipes = new List<Recipe>();

        while (true)
        {
            Console.WriteLine("Enter recipe name or 'exit' when done:");
            var name = Console.ReadLine();

            if (name.ToLower() == "exit")
                break;

            var recipe = new Recipe
            {
                Name = name,
                Ingredients = new List<string>(),
                Units = new List<string>(),
                Instructions = new List<string>()
            };

            while (true)
            {
                Console.WriteLine("Enter ingredient or  'proceed' when done:");
                var ingredient = Console.ReadLine();

                if (ingredient.ToLower() == "proceed")
                    break;

                recipe.Ingredients.Add(ingredient);

                Console.WriteLine("Enter unit of measurement for the ingredient:");
                var unit = Console.ReadLine();
                recipe.Units.Add(unit);
            }

            while (true)
            {
                Console.WriteLine("Enter instructions or  'proceed' when done:");
                var instruction = Console.ReadLine();

                if (instruction.ToLower() == "proceed")
                    break;

                recipe.Instructions.Add(instruction);
            }

            recipes.Add(recipe);
        }

        foreach (var recipe in recipes)
        {
            Console.WriteLine($"Recipe: {recipe.Name}");
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < recipe.Ingredients.Count; i++)
            {
                Console.WriteLine($"- {recipe.Ingredients[i]} ({recipe.Units[i]})");
            }
            Console.WriteLine("Instructions:");
            foreach (var instruction in recipe.Instructions)
            {
                Console.WriteLine($"- {instruction}");
            }
        }
    }
}
